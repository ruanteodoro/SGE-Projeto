﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGE.Domain.Entitles
{
    public class Disciplina
    {
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string Nome { get; set; } = string.Empty;

        [Range(1, 1000)]
        public int CargaHoraria { get; set; }

        public int ProfessorId { get; set; }

        public Professor? Professor { get; set; }
    }
}
