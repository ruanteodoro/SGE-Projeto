﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGE.Domain.Entitles
{
    public class Turma
    {
        public int Id { get; set; }

        [Required]
        [StringLength(80)]
        public string Nome { get; set; } = string.Empty;

        [Range(2020, 2100)]
        public int AnoLetivo { get; set; }

        [Required]
        [StringLength(20)]
        public string Turno { get; set; } = string.Empty;

        public ICollection<Matricula> Matriculas { get; set; }
            = new List<Matricula>();
    }
}
