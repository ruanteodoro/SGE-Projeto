﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGE.Domain.Entitles
{
    public class Matricula
    {
        public int Id { get; set; }

        public DateTime DataMatricula { get; set; }
            = DateTime.Now;

        [Required]
        [StringLength(20)]
        public string Status { get; set; } = "Ativa";

        public int AlunoId { get; set; }

        public Aluno? Aluno { get; set; }

        public int TurmaId { get; set; }

        public Turma? Turma { get; set; }
    }
}
