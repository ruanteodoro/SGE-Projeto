using Microsoft.EntityFrameworkCore;
using SGE.Infrastructure.Data;
using SGE.Application.Interfaces;
using SGE.Infrastructure.Repositores;
using SGE.Application.Services;


var builder = WebApplication.CreateBuilder(args);

// 1. Adicionar servi�os ao container
builder.Services.AddRazorPages();

// 2. Registrar o servi�o de alunos
builder.Services.AddScoped<Alunoservice>();

// 3. Registrar o reposit�rio
builder.Services.AddScoped<IAlunoRepository, AlunoRepository>();

// 4. Configurar o banco de dados
builder.Services.AddDbContext<EscolaDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("ConexaoEscola")
    )
);

// 5. Construir a aplica��o AP�S registrar todos os servi�os
var app = builder.Build();

// 6. Configurar o pipeline HTTP
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapRazorPages();

app.Run();