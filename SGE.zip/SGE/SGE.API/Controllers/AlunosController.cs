﻿using Microsoft.AspNetCore.Mvc;
using SGE.Application.Services;
using SGE.Domain.Entitles;

namespace SGE.API.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AlunosController : ControllerBase
    {
        private readonly Alunoservice _alunoService;

        public AlunosController(Alunoservice alunoService)
        {
            _alunoService = alunoService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Aluno>>> ObterTodos()
        {
            var alunos = await _alunoService.ObterTodosAsync();
            return Ok(alunos);
        }

        [HttpGet("{id:int}")]
        public async Task<ActionResult<Aluno>> ObterPorId(int id)
        {
            var aluno = await _alunoService.ObterPorIdAsync(id);

            if (aluno is null)
                return NotFound(new { mensagem = "Aluno não encontrado." });

            return Ok(aluno);
        }

        [HttpPost]
        public async Task<ActionResult<Aluno>> Adicionar(Aluno aluno)
        {
            try
            {
                var novoAluno = await _alunoService.AdicionarAsync(aluno);

                return CreatedAtAction(
                    nameof(ObterPorId),
                    new { id = novoAluno.Id },
                    novoAluno);
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
        }

        [HttpPut("{id:int}")]
        public async Task<IActionResult> Atualizar(int id, Aluno aluno)
        {
            if (id != aluno.Id)
                return BadRequest(new { mensagem = "O ID da URL não corresponde ao ID do aluno." });

            try
            {
                await _alunoService.AtualizarAsync(aluno);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { mensagem = ex.Message });
            }
        }

        [HttpDelete("{id:int}")]
        public async Task<IActionResult> Remover(int id)
        {
            try
            {
                await _alunoService.RemoverAsync(id);
                return NoContent();
            }
            catch (ArgumentException ex)
            {
                return BadRequest(new { mensagem = ex.Message });
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { mensagem = ex.Message });
            }
        }
    }
}
