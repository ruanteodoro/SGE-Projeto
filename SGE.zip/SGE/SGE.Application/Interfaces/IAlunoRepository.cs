﻿using SGE.Domain.Entitles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGE.Application.Interfaces
{
    public interface IAlunoRepository
    {
        Task<IEnumerable<Aluno>> ObterTodosAsync();

        Task<Aluno?> ObterPorIdAsync(int id);

        Task<Aluno> AdicionarAsync(Aluno aluno);

        Task AtualizarAsync(Aluno aluno);

        Task RemoverAsync(Aluno aluno);

        Task<bool> ExisteCpfAsync(string cpf);
    }
}
