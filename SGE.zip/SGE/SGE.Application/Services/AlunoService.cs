﻿using SGE.Application.Interfaces;
using SGE.Domain.Entitles;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SGE.Application.Services
{
    public class Alunoservice
    {
        private readonly IAlunoRepository _alunoRepository;

        public Alunoservice(IAlunoRepository alunoRepository)
        {
            _alunoRepository = alunoRepository;
        }

        public async Task<IEnumerable<Aluno>> ObterTodosAsync()
        {
            return await _alunoRepository.ObterTodosAsync();
        }

        public async Task<Aluno?> ObterPorIdAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("O ID do aluno deve ser válido.");

            return await _alunoRepository.ObterPorIdAsync(id);
        }

        public async Task<Aluno> AdicionarAsync(Aluno aluno)
        {
            if (string.IsNullOrWhiteSpace(aluno.Nome))
                throw new ArgumentException("O nome do aluno é obrigatório.");

            if (string.IsNullOrWhiteSpace(aluno.CPF) ||
                aluno.CPF.Length != 11 ||
                !aluno.CPF.All(char.IsDigit))
            {
                throw new ArgumentException(
                    "O CPF deve conter 11 números.");
            }

            if (await _alunoRepository.ExisteCpfAsync(aluno.CPF))
                throw new ArgumentException(
                    "Já existe um aluno cadastrado com esse CPF.");

            return await _alunoRepository.AdicionarAsync(aluno);
        }

        public async Task AtualizarAsync(Aluno aluno)
        {
            if (aluno.Id <= 0)
                throw new ArgumentException("O ID do aluno deve ser válido.");

            if (string.IsNullOrWhiteSpace(aluno.Nome))
                throw new ArgumentException("O nome do aluno é obrigatório.");

            var existente = await _alunoRepository.ObterPorIdAsync(aluno.Id);

            if (existente is null)
                throw new KeyNotFoundException("Aluno não encontrado.");

            if (string.IsNullOrWhiteSpace(aluno.CPF) ||
                aluno.CPF.Length != 11 ||
                !aluno.CPF.All(char.IsDigit))
            {
                throw new ArgumentException(
                    "O CPF deve conter 11 números.");
            }

            if (!string.Equals(existente.CPF, aluno.CPF,
                    StringComparison.Ordinal) &&
                await _alunoRepository.ExisteCpfAsync(aluno.CPF))
            {
                throw new ArgumentException(
                    "Já existe outro aluno cadastrado com esse CPF.");
            }

            await _alunoRepository.AtualizarAsync(aluno);
        }

        public async Task RemoverAsync(int id)
        {
            if (id <= 0)
                throw new ArgumentException("O ID do aluno deve ser válido.");

            var aluno = await _alunoRepository.ObterPorIdAsync(id);

            if (aluno is null)
                throw new KeyNotFoundException("Aluno não encontrado.");

            await _alunoRepository.RemoverAsync(aluno);
        }
    }
}
