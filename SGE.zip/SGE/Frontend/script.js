
/*
 * Sistema de Gestão Escolar (SGE)
 * Conexão entre o Front-End e a API ASP.NET Core
 */

// IMPORTANTE: troque a porta pela mesma que aparece
// no endereço do Swagger da sua API, sem acrescentar /swagger.
const API_URL = "https://localhost:7232/";

const modulos = {
    alunos: {
        titulo: "Alunos",
        descricao: "Consulte os alunos cadastrados.",
        endpoint: "/api/Alunos",
        colunas: [
            { chave: "id", titulo: "ID" },
            { chave: "nome", titulo: "Nome" },
            { chave: "cpf", titulo: "CPF" },
            { chave: "dataNascimento", titulo: "Nascimento", tipo: "data" },
            { chave: "email", titulo: "E-mail" },
            { chave: "telefone", titulo: "Telefone" }
        ]
    },
    professores: {
        titulo: "Professores",
        descricao: "Consulte os professores cadastrados.",
        endpoint: "/api/Professores",
        colunas: [
            { chave: "id", titulo: "ID" },
            { chave: "nome", titulo: "Nome" },
            { chave: "cpf", titulo: "CPF" },
            { chave: "email", titulo: "E-mail" }
        ]
    },
    turmas: {
        titulo: "Turmas",
        descricao: "Consulte as turmas cadastradas.",
        endpoint: "/api/Turmas",
        colunas: [
            { chave: "id", titulo: "ID" },
            { chave: "nome", titulo: "Nome" },
            { chave: "anoLetivo", titulo: "Ano letivo" },
            { chave: "turno", titulo: "Turno" }
        ]
    },
    disciplinas: {
        titulo: "Disciplinas",
        descricao: "Consulte as disciplinas cadastradas.",
        endpoint: "/api/Disciplinas",
        colunas: [
            { chave: "id", titulo: "ID" },
            { chave: "nome", titulo: "Nome" },
            { chave: "cargaHoraria", titulo: "Carga horária" },
            { chave: "professor", titulo: "Professor", tipo: "professor" }
        ]
    },
    matriculas: {
        titulo: "Matrículas",
        descricao: "Consulte as matrículas cadastradas.",
        endpoint: "/api/Matriculas",
        colunas: [
            { chave: "id", titulo: "ID" },
            { chave: "aluno", titulo: "Aluno", tipo: "aluno" },
            { chave: "turma", titulo: "Turma", tipo: "turma" },
            { chave: "dataMatricula", titulo: "Data", tipo: "data" },
            { chave: "status", titulo: "Status" }
        ]
    }
};

const inicio = document.getElementById("inicio");
const conteudoModulo = document.getElementById("conteudo-modulo");
const tituloPagina = document.getElementById("titulo-pagina");
const tituloModulo = document.getElementById("titulo-modulo");
const descricaoModulo = document.getElementById("descricao-modulo");
const mensagem = document.getElementById("mensagem");
const cabecalhoTabela = document.getElementById("cabecalho-tabela");
const corpoTabela = document.getElementById("corpo-tabela");

let moduloAtual = null;

async function buscarDados(endpoint) {
    const resposta = await fetch(`${API_URL}${endpoint}`);

    if (!resposta.ok) {
        throw new Error(`A API respondeu com o código ${resposta.status}.`);
    }

    return await resposta.json();
}

function mostrarMensagem(texto, erro = false) {
    mensagem.textContent = texto;
    mensagem.className = erro ? "message visivel erro" : "message visivel";
}

function limparMensagem() {
    mensagem.textContent = "";
    mensagem.className = "message";
}

function formatarValor(item, coluna) {
    let valor = item[coluna.chave];

    if (coluna.tipo === "professor") {
        valor = valor?.nome ?? "-";
    } else if (coluna.tipo === "aluno") {
        valor = valor?.nome ?? "-";
    } else if (coluna.tipo === "turma") {
        valor = valor?.nome ?? "-";
    } else if (coluna.tipo === "data" && valor) {
        valor = new Date(valor).toLocaleDateString("pt-BR", {
            timeZone: "UTC"
        });
    }

    return valor ?? "-";
}

function criarTabela(dados, colunas) {
    cabecalhoTabela.replaceChildren();
    corpoTabela.replaceChildren();

    colunas.forEach(coluna => {
        const th = document.createElement("th");
        th.textContent = coluna.titulo;
        cabecalhoTabela.appendChild(th);
    });

    if (!Array.isArray(dados) || dados.length === 0) {
        const tr = document.createElement("tr");
        const td = document.createElement("td");

        td.colSpan = colunas.length;
        td.textContent = "Nenhum registro encontrado.";
        tr.appendChild(td);
        corpoTabela.appendChild(tr);
        return;
    }

    dados.forEach(item => {
        const tr = document.createElement("tr");

        colunas.forEach(coluna => {
            const td = document.createElement("td");
            td.textContent = String(formatarValor(item, coluna));
            tr.appendChild(td);
        });

        corpoTabela.appendChild(tr);
    });
}

async function carregarModulo(nomeModulo) {
    const modulo = modulos[nomeModulo];

    if (!modulo) return;

    moduloAtual = nomeModulo;
    tituloPagina.textContent = modulo.titulo;
    tituloModulo.textContent = modulo.titulo;
    descricaoModulo.textContent = modulo.descricao;

    const formAluno = document.getElementById("form-aluno");

if (formAluno) {
    formAluno.hidden = nomeModulo !== "alunos";
}

    inicio.hidden = true;
    conteudoModulo.hidden = false;

    limparMensagem();
    mostrarMensagem("Carregando dados...");

    try {
        const dados = await buscarDados(modulo.endpoint);

if (nomeModulo === "alunos") {
    alunosCarregados = Array.isArray(dados) ? dados : [];
}

criarTabela(dados, modulo.colunas);
limparMensagem();
    } catch (erro) {
        console.error("Erro ao carregar dados:", erro);
        criarTabela([], modulo.colunas);

        mostrarMensagem(
            "Não foi possível conectar à API. Verifique se ela está em execução e se a API_URL está correta. " +
            "Se aparecer um erro de CORS no console, será necessário configurar o acesso do Front-End.",
            true
        );
    }
}

async function atualizarResumo() {
    const contadores = [
        { modulo: "alunos", elemento: "total-alunos" },
        { modulo: "professores", elemento: "total-professores" },
        { modulo: "turmas", elemento: "total-turmas" },
        { modulo: "matriculas", elemento: "total-matriculas" }
    ];

    for (const contador of contadores) {
        const elemento = document.getElementById(contador.elemento);

        try {
            const dados = await buscarDados(modulos[contador.modulo].endpoint);
            elemento.textContent = Array.isArray(dados) ? dados.length : "0";
        } catch (erro) {
            console.error(`Erro ao contar ${contador.modulo}:`, erro);
            elemento.textContent = "—";
        }
    }
}

function mostrarInicio() {
    moduloAtual = null;
    tituloPagina.textContent = "Visão geral";
    inicio.hidden = false;
    conteudoModulo.hidden = true;
    atualizarResumo();
}

document.querySelectorAll("[data-secao]").forEach(botao => {
    botao.addEventListener("click", evento => {
        evento.preventDefault();

        const secao = botao.dataset.secao;

        if (secao === "inicio") {
            mostrarInicio();
        } else {
            carregarModulo(secao);
        }
    });
});

document.getElementById("btn-atualizar")
    .addEventListener("click", atualizarResumo);

document.getElementById("btn-recarregar-modulo")
    .addEventListener("click", () => {
        if (moduloAtual) {
            carregarModulo(moduloAtual);
        }
    });

// Carrega os totais ao abrir o painel.
atualizarResumo();

const formAluno = document.getElementById("form-aluno");
const campoAlunoId = document.getElementById("aluno-id");
const tituloFormAluno = document.getElementById("titulo-form-aluno");
const botaoSalvarAluno = document.getElementById("btn-salvar-aluno");
const botaoCancelarAluno = document.getElementById("btn-cancelar-aluno");

function limparFormularioAluno() {
    formAluno.reset();
    campoAlunoId.value = "";
    tituloFormAluno.textContent = "Cadastrar aluno";
    botaoSalvarAluno.textContent = "Salvar aluno";
}

function preencherFormularioAluno(aluno) {
    campoAlunoId.value = aluno.id;
    document.getElementById("aluno-nome").value = aluno.nome ?? "";
    document.getElementById("aluno-cpf").value = aluno.cpf ?? "";
    document.getElementById("aluno-email").value = aluno.email ?? "";
    document.getElementById("aluno-telefone").value = aluno.telefone ?? "";

    document.getElementById("aluno-nascimento").value =
        aluno.dataNascimento
            ? new Date(aluno.dataNascimento).toISOString().slice(0, 10)
            : "";

    tituloFormAluno.textContent = "Editar aluno";
    botaoSalvarAluno.textContent = "Salvar alterações";

    formAluno.hidden = false;
    formAluno.scrollIntoView({ behavior: "smooth", block: "start" });
}

botaoCancelarAluno.addEventListener("click", () => {
    limparFormularioAluno();
    formAluno.hidden = true;
});

formAluno.addEventListener("submit", async evento => {
    evento.preventDefault();

    const id = campoAlunoId.value;

    const aluno = {
        nome: document.getElementById("aluno-nome").value.trim(),
        cpf: document.getElementById("aluno-cpf").value.trim(),
        dataNascimento:
            document.getElementById("aluno-nascimento").value,
        email: document.getElementById("aluno-email").value.trim() || null,
        telefone:
            document.getElementById("aluno-telefone").value.trim() || null
    };

    const metodo = id ? "PUT" : "POST";
    const endpoint = id
        ? `/api/Alunos/${id}`
        : "/api/Alunos";

    botaoSalvarAluno.disabled = true;
    mostrarMensagem("Salvando aluno...");

    try {
        const resposta = await fetch(`${API_URL}${endpoint}`, {
            method: metodo,
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify(aluno)
        });

        if (!resposta.ok) {
            const detalhe = await resposta.text();
            throw new Error(
                `Erro ${resposta.status}: ${detalhe || "Não foi possível salvar."}`
            );
        }

        limparFormularioAluno();
        mostrarMensagem(
            id
                ? "Aluno atualizado com sucesso!"
                : "Aluno cadastrado com sucesso!"
        );

        await carregarModulo("alunos");
        await atualizarResumo();

    } catch (erro) {
        console.error("Erro ao salvar aluno:", erro);
        mostrarMensagem(erro.message, true);
    } finally {
        botaoSalvarAluno.disabled = false;
    }
});

document.getElementById("btn-novo-aluno")
    .addEventListener("click", () => {
        limparFormularioAluno();
        formAluno.hidden = false;
        formAluno.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    });

