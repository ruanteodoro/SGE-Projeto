﻿using SGE.Application.Interfaces;
using SGE.Domain.Entitles;
using SGE.Infrastructure.Data;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;

namespace SGE.Infrastructure.Repositores
{
    public class AlunoRepository : IAlunoRepository
    {
        private readonly EscolaDbContext _context;

        public AlunoRepository(EscolaDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Aluno>> ObterTodosAsync()
        {
            return await _context.Alunos
                .AsNoTracking()
                .ToListAsync();
        }

        public async Task<Aluno?> ObterPorIdAsync(int id)
        {
            return await _context.Alunos
                .FirstOrDefaultAsync(a => a.Id == id);
        }

        public async Task<Aluno> AdicionarAsync(Aluno aluno)
        {
            _context.Alunos.Add(aluno);
            await _context.SaveChangesAsync();

            return aluno;
        }

        public async Task AtualizarAsync(Aluno aluno)
        {
            _context.Alunos.Update(aluno);
            await _context.SaveChangesAsync();
        }

        public async Task RemoverAsync(Aluno aluno)
        {
            _context.Alunos.Remove(aluno);
            await _context.SaveChangesAsync();
        }

        public async Task<bool> ExisteCpfAsync(string cpf)
        {
            return await _context.Alunos
                .AnyAsync(a => a.CPF == cpf);
        }
    }
}
