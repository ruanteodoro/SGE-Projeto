﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using SGE.Infrastructure.Data;

namespace SGE.Infrastructure.Data;

public class EscolaDbContextFactory
    : IDesignTimeDbContextFactory<EscolaDbContext>
{
    public EscolaDbContext CreateDbContext(string[] args)
    {
        var optionsBuilder =
            new DbContextOptionsBuilder<EscolaDbContext>();

        optionsBuilder.UseSqlServer(
            "Server=(localdb)\\MSSQLLocalDB;" +
            "Database=SistemaGestaoEscolarDB;" +
            "Trusted_Connection=True;" +
            "TrustServerCertificate=True;");

        return new EscolaDbContext(optionsBuilder.Options);
    }
}
