﻿
using Microsoft.EntityFrameworkCore;
using SGE.Domain.Entitles;
using System.Collections.Generic;
using System.Reflection.Emit;


namespace SGE.Infrastructure.Data;

public class EscolaDbContext : DbContext
{
    public EscolaDbContext(
        DbContextOptions<EscolaDbContext> options)
    : base(options)
    {
    }

    public DbSet<Aluno> Alunos => Set<Aluno>();

    public DbSet<Professor> Professores => Set<Professor>();

    public DbSet<Turma> Turmas => Set<Turma>();

    public DbSet<Disciplina> Disciplinas => Set<Disciplina>();

    public DbSet<Matricula> Matriculas => Set<Matricula>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Aluno>()
            .HasIndex(a => a.CPF)
            .IsUnique();

        modelBuilder.Entity<Professor>()
            .HasIndex(p => p.CPF)
            .IsUnique();

        modelBuilder.Entity<Disciplina>()
            .HasOne(d => d.Professor)
            .WithMany(p => p.Disciplinas)
            .HasForeignKey(d => d.ProfessorId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Matricula>()
            .HasOne(m => m.Aluno)
            .WithMany(a => a.Matriculas)
            .HasForeignKey(m => m.AlunoId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Matricula>()
            .HasOne(m => m.Turma)
            .WithMany(t => t.Matriculas)
            .HasForeignKey(m => m.TurmaId)
            .OnDelete(DeleteBehavior.Restrict);
    }
}
